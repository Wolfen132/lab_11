// Завдання №2
// alert("Очеретнюк")

// Завдання №3
// let number = 24;
// let str = "Слава Україні";
// alert( number);
// alert( str);
// number = str;
// alert( number);
// alert( str);

// Завдання №4
// newObj ={
// name: "Богдан",
// age: 18,
// isAdult: true,
// notingh: undefined,
// zero: null
// };

// Завдання №5
// let isAdult = confirm("Ви повнолітні?");
// console.log(isAdult);

// Завдання №6
// let name = "Богдан";
// let surname = "Очеретнюк";
// let group = "КН-321";
// let age = 2005;
// let Marital_status = false;
// console.log("age = ",typeof age);
// console.log("Marital_status = ",typeof Marital_status);
// console.log("name = ",typeof name);
// console.log("surname = ",typeof surname);
// console.log("group = ",typeof group);
// let zero = null;
// let notingh = undefined;
// console.log("null = ",typeof zero);
// console.log("notingh = ",typeof notingh);

// Завдання №7
// let login = prompt("Введіть логін");
// let email = prompt("Введіть емейл");
// let password = prompt("Введіть пароль");
// console.log("Dear ",login,", your email is ", email," , your password is ",password );

//Завдання №8
let hour = 60 * 60;
let day = 24 * 60 * 60;
let month = 30 * 24 * 60 * 60;
console.log("Секунд в годині = ", hour);
console.log("Секунд в дні = ", day);
console.log("Секунд в місяці = ", month);